
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'tp' 
 * Target:  'Target 1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "device_registers.h"

/* Keil::Device:Startup:2.0.0 */
#define RTE_DEVICE_STARTUP_S32K      /* Device Startup for S32K Series */


#endif /* RTE_COMPONENTS_H */
